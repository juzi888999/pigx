/*
 * @author intelligence archetype
 * <p>
 * DTO 存放目录
 */
package ${package}.dto;