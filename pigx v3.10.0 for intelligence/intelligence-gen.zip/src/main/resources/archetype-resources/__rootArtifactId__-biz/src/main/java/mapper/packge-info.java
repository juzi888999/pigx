/*
 * @author intelligence archetype
 * <p>
 * Mybatis Mapper 存放目录
 */
package ${package}.mapper;