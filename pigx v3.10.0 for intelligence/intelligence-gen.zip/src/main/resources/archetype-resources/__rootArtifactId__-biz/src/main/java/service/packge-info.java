/*
 * @author intelligence archetype
 */
package ${package}.service;